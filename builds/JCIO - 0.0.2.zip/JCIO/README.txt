Windows users can double click the BAT file. Mac/Linux have to open the JAR manually:
1) Open console
2) run: "java -jar Myjar_file.jar"